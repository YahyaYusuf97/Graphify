This batch changes one flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). It was published as 144.0 at handover. **Check the live published version first and work from that, not from 144.** These changes come from the client's 4th test (`4th TEST -WhatsApp - Aljomaih - Alwesal.xlsx`, tester: Amal, 11 notes).

Before anything, read `CLAUDE.md`, then `05 - Documentation/Aljomaih WhatsApp Bot - Complete Technical Documentation.md` (§4, §5, Appendix R1) and `Project History.md`.

## Method (mandatory, same as every batch)
- Run `python "04 - Scripts/check_env.py"` and `python "04 - Scripts/checks/audit_full.py"` (expect `no issues`) before you start.
- Credentials come only from `creds/` or environment variables. **Never print, paste or ask for a secret in chat.**
- **Never send any project file, config or export to a third-party service.** Only Genesys Cloud (and Oracle through data actions).
- **Do not modify the inbound message flow `Hadef_BusinessWhatsApp`.** Reading it is allowed.
- Flow edits go in place through the Architect Scripting SDK (`04 - Scripts/sdk/run.sh <script.ts>`).
  - Load with `checkoutAndLoadFlowByFlowNameAsync("Aljomaih Automotive WhatsApp ", digitalBot, forceUnlock=false)`.
  - **NEVER** use `deploy_flow` or `createFlow*Async`.
  - If the flow is locked, stop and tell me.
  - Check the flow id after checkout and again before publish. Validate; on any error unlock without saving and report.
- First back up the published config and the ar-ae NLU domain version to `02 - Flow Exports/`.
- **Never touch message-builder-mode blocks.** List them for me; I edit them by hand after your publish. Every new Communicate, prompt or label you add must be **expression mode**, branched on `Session.language == "ar-ae"`.
- **WhatsApp limits:** buttons ≤ 20 characters; list rows ≤ 24; list question/title ≤ 20; max 10 rows. One over-long option = the whole message is not delivered.
- **Navigation labels stay byte-identical:** «القائمة السابقة ↩️», «القائمة الرئيسية 🏠», «إنهاء المحادثة 👋» / "Previous Menu ↩️", "Main Menu 🏠", "End Chat 👋".
- **Expressions:** no `not` (use `IsNotSetOrEmpty(x) == false`), no `Random`, no `Min`. `DayOfWeek()` 1 = Sunday.
- **Diff the published config before and after.** Only the blocks named in this batch may change or be added. Intent→task mappings and all other list bindings must be identical.
- **Never create bookings, test drives, cancellations, emails or transfers from automated tests.**
- Before writing code, read the flow and give me a **short plan per item**, including which items are impossible or need a client decision. Then run the feasible items without waiting for me, unless something is ambiguous.

---

## 1. No-input timeout gets its own goodbye (sheet row 1)
**Today:** `noInputsMaxExceededTaskName = Exit`, so a silent customer only gets «شكرًا لتواصلك مع الجميح للسيارات. 🚗» — the same text as End Chat.

**Change:**
1. Create a new reusable task **"Timeout Exit"**: one expression-mode Communicate, then Disconnect (same end as task Exit).
   - AR: «لم نتلقَّ ردًا منك، لذلك سيتم إنهاء المحادثة. يمكنك التواصل معنا مجددًا في أي وقت.\nشكرًا لتواصلك مع الجميح للسيارات. 🚗»
   - EN: "We haven't received a reply from you, so this chat will now end. You can contact us again at any time.\nThank you for contacting Aljomaih Automotive. 🚗"
2. Set the flow-level `noInputsMaxExceededTaskName` to **Timeout Exit**.
3. Find every **Max No Inputs** path that jumps straight to **Exit** (e.g. After Service Menu 1490/1495, main menus, section menus) and point it to **Timeout Exit** instead. Keep End Chat, «شكرا», the Exit intent and Fallback Router → End Chat on the old **Exit** task.
4. Report every block you re-pointed.

## 2. Booking confirmation format (sheet row 2)
**Today:** 824 (builder mode) shows number, centre, city, `Slot.appDate` (yyyy-MM-dd), `Slot.appTime`.

**Client's target (AR):**
```
تم حجز الموعد بنجاح والتفاصيل كالتالي
رقم الموعد : {appId}
مركز الصيانة : {bkCenter}
المدينة : {bkCity}
التاريخ : {dd/MM}
التوقيت : {hh:mm ص/م}

يرجى التأكد من زيارة ورشة العمل قبل 15 دقيقة من موعدك
نشكركم لتواصلكم معنا في شركة الجميح للسيارات و نسعد بخدمتكم دائماً
```
(The client wrote «يخدمتكم»; that is a typo for «بخدمتكم».)

**Change (tool part only):**
1. In the same Update Data that sets `Flow.bkCenter` / `Flow.bkCity` (1766), add:
   - **`Flow.bkDate`** = the picked date as **dd/MM** (e.g. 30/09).
   - **`Flow.bkTime`** = the picked time in 12-hour form: AR «08:00 ص» / «02:30 م», EN "08:00 AM" / "02:30 PM". First check what `Slot.appTime` actually holds (24h value or a label) and tell me.
   - Guard every expression so the block can never fail; on bad input fall back to the raw slot value.
2. Don't touch 824; I rewrite it by hand. Give me the English version to paste as well:
   "Your appointment has been booked successfully. Details:\nAppointment number: {appId}\nService center: {bkCenter}\nCity: {bkCity}\nDate: {bkDate}\nTime: {bkTime}\n\nPlease make sure to visit the workshop 15 minutes before your appointment.\nThank you for contacting Aljomaih Automotive. We are always happy to serve you."
3. The client's sample ends with only «إنهاء المحادثة» and «القائمة الرئيسية». Today After Service Menu also shows «القائمة السابقة». **Don't change it**; just confirm what is shown after 824 so I can tell the client.

## 3. Smart Assistant: language, formatting and handoff (sheet row 3)
**What the tester saw (Arabic session):**
- The customer typed in **English** ("hi", "i need to book an appointment") and the assistant answered in **Arabic**. This is prompt v12's LANGUAGE rule (`[LANG=ar]` = `Session.language` overrides the typed language).
- Raw markdown showed: `**Chevrolet**`, `*GMC*`. Prompt v12 tells the model to bold with **double** asterisks; WhatsApp only renders single `*`.
- «هل تحتاج مساعدة أخرى؟» was highlighted by the client.
- The handoff "سأنقلك الآن إلى خيار حجز موعد الصيانة" → Aftersales worked.

**Client requirement:** if the customer starts writing in English, the bot **continues in English**: the assistant's answer **and** everything after it (handoff menus, After Service Menu, the rest of the chat). Same for Arabic in an English session.

**Change:**
1. Read task OpenAI and the input of `ChatGPT_OpenAI_2026` / `…_FollowUp_2026` (the prompt v12 text is in the flow's data-action input and in `03 - Deliverables/ai_prompt_v12.txt`). Plan **prompt v13**:
   - **LANGUAGE:** reply in the language of the customer's **latest message**; use the `[LANG=..]` tag only when the message has no clear language (numbers, emojis, symbols).
   - **Language marker:** the model ends every reply with a hidden tag, `[[L=en]]` or `[[L=ar]]`, for the language it answered in. Never explain it.
   - **STYLE:** WhatsApp formatting only: single asterisks `*text*` for bold, never `**`; or no bold at all. Also, in the flow, after the action returns, replace any `**` with `*` in the answer before sending it, as a safety net (expression mode, guard against empty).
   - **CLOSING (client-approved):** keep the closing question once, **in the same language as the reply**: Arabic reply → «هل تحتاج مساعدة أخرى؟», English reply → "Do you need further help?". Never the Arabic one after an English answer (as in the tester's screenshot), and never both.
   - Don't touch RULE 1–5, the official links, the price rule or the routing tags.
2. **Switch the session language (build it):** in task OpenAI, after each action returns (first answer and follow-ups):
   - read the `[[L=..]]` tag and strip it from the answer before sending (guard: no tag → change nothing);
   - if the tag differs from `Session.language`, run **SetLocale** (`en-us` / `ar-ae`) and set **`Flow.apiLang`** (`US` / `AR`) the same way Language Router 1404/1406 does;
   - so the answer, every handoff (`[[SERVICE]]`, `[[SALES]]` …) and all later menus come out in the new language through the normal routers.
   - If you find a simpler or safer way to detect the language in Architect (without the tag), propose it before building.
   - Check the routing-tag handling still works with the extra tag at the end.
3. Save the new prompt as `03 - Deliverables/ai_prompt_v13.txt` and show me the diff from v12 before you put it in the flow.

## 4. Welcome and language at the start (sheet row 4)
**Client wants:**
- Customer opens in Arabic («مرحبا», «السلام عليكم» …) → Arabic, no language question. English → English.
- Only if the first message is symbols or unclear («-», «.», «..») → a **bilingual** picker:
  «أهلاً بك في شركة الجميح للسيارات\nWelcome to Aljomaih Automotive» with buttons «العربية» / "English".
- After the language is known, the welcome text becomes:
  - AR: «أنا مساعدك الذكي من شركة الجميح للسيارات ، و تسعدني خدمتك\n\nنود التنويه بأن المعلومات التي تشاركونها معنا قد تُستخدم من قبل شركة الجميح للسيارات أو شركائها للتواصل معكم وتقديم الخدمات والعروض. إذا كنتم لا ترغبون في ذلك، يرجى إبلاغنا.»
  - EN: "I'm your smart assistant from Aljomaih Automotive, happy to help you.\n\nPlease note that the information you share with us may be used by Aljomaih Automotive or its partners to contact you and to offer services and promotions. If you prefer that we don't, please let us know."
  - then the main menu.

**Constraints:** `Flow.language` is a flow **input** set by `Hadef_BusinessWhatsApp`, which we may not modify. Don't rewire 955/966 to `Session.language` (Handover §8.9).

**Do:**
1. **Read only** `Hadef_BusinessWhatsApp` and tell me: how it detects the language, what it passes for symbols/unclear text, and whether the first message text reaches the bot (any input variable or `Session` value).
2. If the bot can tell "unclear" apart (e.g. an input value other than ar/en, or the first-message text), propose the bilingual picker inside Initial Greeting (new expression-mode Digital Menu, buttons «العربية» / "English" → SetLocale → welcome → main menu). If it can't without changing the inbound flow, say so; don't build a workaround.
3. The welcome text comes from table **`AAC_Welcome`** (key `WELCOME`). Show me the current `message_ar` / `message_en`, and the new values above. **Don't update the table until I confirm.** Check the welcome blocks (71/72, 969/973) don't add their own text around it.

## 5. «تغيير اللغة» shown in both languages (sheet row 5)
Client asks for «تغيير اللغة - Change language» in the main menu so every user sees it is the language option. **That is 29 characters, over the 24 row limit.** These shorter labels are **approved**; use exactly:
- Main menu AR (77): **«تغيير اللغة / English»** (21)
- Main menu EN (17): **"Change Language / عربي"** (22)

Change only the label (and choice name/value if repeated). Keep the path to the Language Router / SetLocale. Count the characters in code and report them. Check the "Change Language" intent and the typed «عربي» / "English" still work at those menus.

## 6. «السلام عليكم» gets "تقصد تغيير اللغة، صح؟" (sheet row 6)
**What happened:** customer opened with «السلام عليكم» → welcome → bot asked «تقصد تغيير اللغة، صح؟» (Yes/No).

**Do:**
1. Find out why: is the opening message being evaluated by the first Digital Menu (77) against the intents, and why does it low-confidence-match "Change Language"? Check the ar-ae NLU version utterances and the confidence thresholds (low 10 / high 30).
2. Propose the smallest fix, e.g.:
   - make the first menu after the greeting not consume the opening message, or
   - add a greeting / Main Menu intent with Arabic and English greetings («السلام عليكم», «مرحبا», «هلا», «hello», «hi» …) mapped to the main menu, so they win over Change Language.
3. If the fix needs an NLU change, back up the ar-ae NLU version first, and confirm afterwards that every other intent's utterances are unchanged. Test with Textbots: «السلام عليكم», «مرحبا», «hi», «hello», «-», «.» — none must trigger the Change Language confirmation.

## 7. "Sorry. Main menu" / «عفواً الصيانة» on no-input reprompt (sheet row 7)
**What happened:** when the customer waits, the menu is re-sent with "Sorry. Main menu" / «عفواً الصيانة» / «عفواً أي شهر؟».

**Client wants** the reprompt to say:
- AR: «لم يتم اختيار أي خيار. يرجى الاختيار من القائمة للمتابعة»
- EN: "No option selected. Please select from the menu to continue."

**Do:**
1. Find where "Sorry." / «عفواً» is added (flow-level no-input reprompt, per-menu noInput prompts, or the platform default). Report it.
2. The list title (= question) must stay ≤ 20 characters, so the long text can't be the list title. Propose how to send it, e.g. a body/Communicate before the re-sent menu while the list title stays the original question. Show me which blocks this touches across all menus and questions before building; if it is only a flow-level setting, change it there.

## 8. Parts request and Contact Us emails are missing fields (sheet rows 8 and 11)
**Today:**
- Parts (task Parts Inquiry): make, model, year, VIN, mobile → `Flow.inquiryBody` (707) → `Graph_Send_Mail` (1713–1720).
- Contact Us: message (`Slot.AnyInput`) → mobile → email.

**Client wants** the old-bot fields:
- **Parts / Accessories:** add **name**, **city**, **email**, **request details** (e.g. «مجموعه فتح الزجاج»).
- **Contact Us:** add **name**, **city**, **email**.

**Change:**
1. Add the questions in expression mode, before the mobile question:
   - Name: free text, AR «الاسم؟» / EN "Your name?"
   - City: reuse an existing city/region list if there is a suitable one (say which: `AAC_Regions`, `AfterSales_GET_CITY`, …), paged with Previous/Main, title ≤ 20. If none fits, free text.
   - Email: **required**, free text, AR «البريد الإلكتروني؟» / EN "Your email?". Validate it (contains `@` and a `.` after it, no spaces); if invalid, re-ask with AR «يرجى إدخال بريد إلكتروني صحيح» / EN "Please enter a valid email address". No skip option.
   - Request details (Parts only): free text, AR «تفاصيل الطلب؟» / EN "Request details?"
   - Each question has its own no-match text and Max No Matches → Fallback Router (backTo = PARTS / CARE).
2. Add the new fields to the email body and subject (707 / Contact Us body), in this order for Parts: VIN, mobile, email, city, name, make, model, year, request details, language, Saudi time. Contact Us: name, mobile, email, city, message, language, Saudi time.
3. Keep `AAC_Email_Settings` keys and recipients unchanged. **Don't send a test email**; I test on WhatsApp.
4. If 707 or the confirmation (708) is builder mode, list it for me instead of editing.

## 9. Agent sends the customer back to the bot (sheet row 9) — feasibility only, no build
Client asks: can an agent in Live Chat return the customer to a bot menu (e.g. a customer who wanted to book an appointment: the agent says "you can book through the bot, transferring you now" and the customer lands in the booking menu)?

Investigate and report only:
- whether Genesys Cloud lets an agent transfer a WhatsApp/messaging interaction to an Architect flow (or a queue/flow that re-enters this bot), and what licence/feature it needs;
- whether it can target a specific task (e.g. Book Service Appointment) via a participant attribute or flow input;
- whether any option requires changing `Hadef_BusinessWhatsApp` (not allowed without approval).
Give me 2–3 options with pros/cons. Change nothing.

## 10. Customer Care → Previous Menu (sheet row 10) — check only
Client tested: Customer Care → Services Provided → Previous → Customer Care, and Customer Care → Services Provided → Mobile App → Previous → Customer Care. Confirm with Textbots (or by reading 1360/1366 and Mobile App Link) that both paths return to the Customer Care menu in both languages. No change unless it is broken.

---

## Tests after publish (Textbots; no bookings, test drives, emails or transfers)
1. Main menu AR/EN: 10 options, new language labels, lengths ≤ 24; tapping/typing the language option switches language.
2. Opening messages «السلام عليكم», «مرحبا», «hi», «hello», «-», «.»: no Change Language confirmation; right language.
3. Timeout: show me the new wiring (flow setting + re-pointed Max No Inputs paths). Textbots can't wait 5 minutes.
4. Smart Assistant, Arabic session: "hi" and "i need to book an appointment" → English answer with no `**` and no visible `[[L=..]]`, closing with "Do you need further help?" (not the Arabic one), then the Aftersales menu **in English**, and the main menu stays English after that. Reverse test: English session + «عايز أحجز موعد صيانة» → Arabic all the way.
5. Parts / Contact Us: walk the new questions as far as Textbots allows, stop before the email is sent.
6. Customer Care Previous paths (item 10).
7. Run `checks/audit_full.py` (expect `no issues`) and `checks/long_questions.py`.

## Report
- the new version number(s);
- per item 1–10: blocks changed or added (tracking ids), or why not done;
- the diff summary;
- answers: 2 (`Slot.appTime` content, what follows 824), 3 (how the language switch works), 4 (inbound-flow findings), 6 (root cause), 7 (where «عفواً» comes from), 8 (city source), 9 (options);
- the test results;
- a list of **builder-mode blocks I must edit by hand**, with the exact AR and EN text for each.

Save the backups, `ai_prompt_v13.txt` and `03 - Deliverables/Change Batch <date> - v<NNN> Report.md` in the project folder, update `Client Feedback Tracker.xlsx` with the 4th-test rows, regenerate the docs (`docs/build_tech_reference.py`, `docs/build_full_doc.py`), and check that nothing contains a secret.

**Need my confirmation before:** updating `AAC_Welcome` (item 4), any NLU change (item 6), and anything in item 9.
