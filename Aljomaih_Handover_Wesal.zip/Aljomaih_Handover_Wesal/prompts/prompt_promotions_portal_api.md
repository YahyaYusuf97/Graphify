This batch moves the bot's **promotions** from the data table `AAC_Promotions` to the new **Wesal promotions portal API**. Flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). Nothing else in the flow may change.

## The API (already tested, read-only GET)
- Base: `https://portal.wesal.cloud/api/bot/promotions`
- Auth: header `x-api-key: <BOT_API_KEY>`. Without it → **401**.
- **One promotion:** `GET /api/bot/promotions/{key}`, key URL-encoded (`1|CAPTIVA` → `1%7CCAPTIVA`).
  - Found → **200** with one object.
  - Not found → **404** `{"found":false,"key":"1|NOPE"}`.
- **All promotions:** `GET /api/bot/promotions` → `{"entities":[…],"total":10}`.
- Object fields (same as the `AAC_Promotions` columns):
  `key, make, brand, model_year, promo_name_en, promo_name_ar, start_date (yyyy-MM-dd), end_date (yyyy-MM-dd), media_en, media_ar, status (Active/Inactive), created_by, creation_date, last_updated_by, last_updated_date`.
- Keys follow the table: `make|brand` (e.g. `1|CAPTIVA`, `T|YUKON`), plus `SERVICE|ALL` and `PARTS|ALL`.
- **The API does not filter by date:** rows that ended on 2026-09-30 are still returned as `Active`. The bot must check the dates.

## The API key
- **I will give you the key in a separate step; it is not in this prompt.** Ask me where to put it (a local creds file such as `creds/promo_portal_creds.json`, or I'll enter it in the Genesys UI myself).
- It must live **only in the integration's credentials**, never in the data action config, the flow, an export, a report or chat. Never print it.

## Method (mandatory)
- Read `CLAUDE.md` first. Run `check_env.py` and `checks/audit_full.py` (expect `no issues`).
- **Don't modify `Hadef_BusinessWhatsApp`.**
- In-place SDK edit only (`checkoutAndLoadFlowByFlowNameAsync(..., forceUnlock=false)`; **never** `deploy_flow` / `createFlow*Async`). If the flow is locked, stop and tell me. Check the flow id after checkout and before publish; validate; unlock without saving on any error.
- Back up the published config, the ar-ae NLU version and the `AAC_Promotions` table to `02 - Flow Exports/` first.
- **Don't delete or change the `AAC_Promotions` table**; it stays as a backup.
- New texts in expression mode on `Session.language == "ar-ae"`; builder-mode blocks → list them for me. WhatsApp limits and byte-identical navigation labels as always.
- Data actions: create new ones; never change a published contract (make a `V2` if needed). Use `/draft` → test → `/draft/publish`.
- Nothing is sent to any other service. The portal API is called only through the new Genesys data action.

## Step 0 – read and report before changing
1. Current published version.
2. Every place the flow reads promotions: the **Data Table Lookup on `AAC_Promotions`** in *Sales Promo Models 🎁* (key `make|brand`), in *Promo Direct* (`SERVICE|ALL`, `PARTS|ALL`), and any other. For each give the block id, the key expression, the output variables it fills, and what Found / Not Found / Failure do today.
3. How the image is sent (`media_ar` / `media_en`) and the `AAC_PromoLog` click logging.

Then give me a short plan and wait for my OK.

## Change
### 1. Integration and data action
1. Create a **Web Services Data Actions** integration **"Wesal Promotions Portal"** with a **User Defined** credential field `apiKey` (value = the key, set as agreed above).
2. Create the data action **`Wesal_Get_Promotion`**:
   - Input: `key` (string).
   - Request: `GET https://portal.wesal.cloud/api/bot/promotions/$esc.url(${input.key})`, header `x-api-key: ${credentials.apiKey}`.
   - Output (all strings): `key, make, brand, model_year, promo_name_en, promo_name_ar, start_date, end_date, media_en, media_ar, status`. Map nulls to "".
   - A **404** makes the action take the Failure path. Find out whether the response template can turn a 404 into a normal result with `found = false` instead; if it can, use it and add an output `found` (true/false). If it can't, Failure means "no promotion".
3. Test it with `/draft/test` for `1|CAPTIVA` (found), `SERVICE|ALL` (found), `1|NOPE` (not found). Show me the results (not the key).

### 2. Flow
1. Replace each `AAC_Promotions` Data Table Lookup (Step 0) with a **Call Data Action → `Wesal_Get_Promotion`** using the **same key expression** and filling the **same variables**, so the blocks after it need no change.
2. **Show a promotion only if it is valid:** `status == "Active"` **and** today in Saudi time (`Asia/Riyadh`, UTC+3) is between `start_date` and `end_date`, inclusive. Compare as dates and guard against empty or bad dates so the block never fails. If either date is empty, treat that side as open.
3. Not found, invalid dates, Inactive, Failure or Timeout → the **same "no promotions" message and path** as today's Not Found.
4. Keep the image sending, the `AAC_PromoLog` logging, the post-promo menu (Test Drive / Price Range / Previous / Main) and `Flow.fromPromo` exactly as they are.

### 3. Optional (propose only, don't build)
With `GET /api/bot/promotions` (all rows) the bot could show only the makes/model lines that have a **valid** promotion instead of every model line from Oracle. Tell me what it would take; don't build it now.

## Tests after publish (Textbots)
1. Sales → Current Promotions → Chevrolet → Captiva → the Captiva image (valid until 2026-12-31).
2. Chevrolet → Tahoe → "no promotions" (its promotion ended 2026-09-30, though it is still `Active`).
3. Aftersales → Promotions (`SERVICE|ALL`) and Parts → Promotions (`PARTS|ALL`) → image.
4. A model line with no row → "no promotions".
5. Main menu Promotions path, Arabic and English.
6. Run `checks/audit_full.py` (expect `no issues`) and `checks/long_questions.py`.

## Report
- the new version number;
- the integration and data action ids, and the `/draft/test` results;
- the blocks replaced (old → new, tracking ids) and the diff summary;
- how 404 is handled (found flag or Failure);
- the date check expression;
- the test results;
- builder-mode blocks I must edit by hand, if any;
- the answer to the optional item.

Save the backups and `03 - Deliverables/Change <date> - v<NNN> Promotions from portal API.md`, update the Technical Documentation (promotions section and the APIs appendix) and the Data Tables Guide (`AAC_Promotions` is now a backup; promotions are managed in the portal), and check that nothing contains a secret, **including the API key**.
