This batch changes one flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). These changes come from the client's **5th test** (`5th TEST -WhatsApp - Aljomaih - Alwesal.xlsx`, tester: Amal, 18 notes, sheet "Amal"). Read the sheet and its screenshots yourself as well.

Before anything, read `CLAUDE.md`, the *Complete Technical Documentation* (§4, §5, Appendix R1), the *Project History*, the 4th-batch prompt (`prompt_4th_test_batch.md`) and its change report, if there is one.

## Method (mandatory, same as every batch)
- Run `python "04 - Scripts/check_env.py"` and `python "04 - Scripts/checks/audit_full.py"` (expect `no issues`) before you start.
- Credentials come only from `creds/` or environment variables. **Never print, paste or ask for a secret in chat.**
- **Never send any project file, config or export to a third-party service.** Only Genesys Cloud, and Oracle/OpenAI/Graph **only through the existing data actions**. One exception, approved for this batch: **public Aljomaih website content** may be uploaded to the assistant's OpenAI vector store (Phase 3.5), after I approve the page and file list.
- **Do not modify the inbound message flow `Hadef_BusinessWhatsApp`.** Reading it is allowed.
- Flow edits go in place through the Architect Scripting SDK (`04 - Scripts/sdk/run.sh <script.ts>`).
  - Load with `checkoutAndLoadFlowByFlowNameAsync("Aljomaih Automotive WhatsApp ", digitalBot, forceUnlock=false)`.
  - **NEVER** use `deploy_flow` or `createFlow*Async`.
  - If the flow is locked, stop and tell me.
  - Check the flow id after checkout and again before publish. Validate; on any error unlock without saving and report.
- First back up the published config, the ar-ae NLU domain version and any data table you will touch to `02 - Flow Exports/`.
- **Never touch message-builder-mode blocks.** List them for me with the exact AR/EN text; I edit them by hand after your publish. Every new Communicate, prompt or label must be **expression mode**, branched on `Session.language == "ar-ae"`.
- **WhatsApp limits:** buttons ≤ 20 characters; list rows ≤ 24; list question/title ≤ 20; max 10 rows. One over-long option = the whole message is not delivered.
- **Navigation labels stay byte-identical:** «القائمة السابقة ↩️», «القائمة الرئيسية 🏠», «إنهاء المحادثة 👋» / "Previous Menu ↩️", "Main Menu 🏠", "End Chat 👋".
- **Expressions:** no `not` (use `IsNotSetOrEmpty(x) == false`), no `Random`, no `Min`. `DayOfWeek()` 1 = Sunday.
- **Diff the published config before and after.** Only the blocks named in your approved plan may change.
- **Never create bookings, test drives, cancellations, emails or transfers from automated tests.**

## Step 0 – where are we? (report before planning)
1. The current published version and who published it.
2. **Which 4th-batch items are live** (timeout task, booking confirmation values, prompt v13 + language switch, welcome/language picker, language labels, «السلام عليكم» fix, no-input reprompt, parts/contact fields, email). The 5th test shows «السلام عليكم» still asking "Change Language?", so at least item 6 is not live or not working.
3. The live OpenAI action request body: model, the instructions version, and whether it uses `file_search` / a vector store (the assistant says «الملفات المتاحة لدي»). Don't print the API key.

**This batch is big. After Step 0, send me a plan per item (blocks, approach, risks, what needs the client) and wait for my OK before you build.** Build it in the phases below, one publish per phase, each verified.

---

## Phase 1 – Language and the start of the chat (notes 3, 4, 5)

**What the tester saw:**
- «مرحبا» → "Main menu" in **English** (note 3).
- «هلا» → "I think you want to Main Menu, is that correct?"; «لا» → "Sorry, please reply with "Yes" or "No""; «السلام عليكم» → "I think you want to Change Language, is that correct?" — all in English during an Arabic chat (note 4).
- After choosing Arabic, the welcome + privacy message was **not** shown (note 5).
- Typing «انهاء المحادثة» during a Yes/No confirmation was ignored (note 5).

**Client requirements:**
- Arabic greeting → Arabic; English → English.
- Anything about choosing the language is shown **in both Arabic and English**.
- The welcome + privacy message is **always** shown at the start of every new chat, including after the customer picks a language at the start.

**Do:**
1. Find the root cause of «مرحبا» → English. Check: what `Hadef_BusinessWhatsApp` passes in `Flow.language` for «مرحبا»/«هلا»; whether the bot session simply **continued from an earlier English session** (see Phase 2, chat not ending); and whether the 4th-batch language switch (OpenAI `[[L=..]]` → SetLocale) left the session in English.
2. Fix the greeting so «مرحبا», «هلا», «السلام عليكم», «اهلا», «hi», «hello» go to the main menu in the right language with **no** confirmation question. (Greeting intent/utterances, or the first menu not consuming the opening message — your choice, explain it.)
3. Welcome + privacy (`AAC_Welcome`) must run on **every** entry path into a new chat, including the start-of-chat language picker. Don't show it again on a mid-chat «تغيير اللغة».
4. Any language picker/confirmation must be bilingual: «العربية» / "English" buttons, with a bilingual question.
5. **Yes/No confirmations** («تقصد … صح؟»):
   - accept Arabic and English answers in both sessions (نعم/ايوه/اي/yes, لا/no);
   - typed «إنهاء المحادثة» / "end chat" / «القائمة الرئيسية» / "main menu" must work there too;
   - make them rare: tell me the current thresholds (low 10 / high 30) and propose new values so normal greetings and clear requests don't trigger a confirmation.
6. **"No" on a confirmation** today shows «عفواً، خطأ مني. أخبرني مرة أخرى بما تريد فعله.» and then re-sends the **current menu** with the list title cut to «عفواً، خطأ مني. أخب…» (over 20 characters, note 15 screenshot). Fix it so that "No" returns the customer to where they were (the assistant if they came from it, otherwise the main menu) and no list title is ever over 20 characters. Find where this text lives (bot-level confirmation-rejection prompt?) and report.

## Phase 2 – Timeouts, ending the chat, and a way out of every question (note 7 + general note)

**Client requirements:**
- No reply: reminder after **2 minutes**, the chat ends at **5 minutes** with the 4th-batch Timeout Exit message.
- If the customer closes WhatsApp and comes back later, the bot must **not** continue the last request (it was still waiting for the mobile number: «رقم غير صحيح. من فضلك أرسل رقم جوال يبدأ بـ 05»).
- Every free-text question (VIN, mobile, email, city, name, details…) must give a way back or out. The customer typed «القائمة الرئيسية» at the mobile question and got "invalid number".

**Do:**
1. Set the flow no-input settings to get: reminder at ~2 min, end at ~5 min. Tell me the exact `noInputsTimeout` / `noInputsMax` semantics you confirmed and the resulting timeline.
2. Confirm that after Timeout Exit / Exit the conversation is really disconnected, so the next message starts a new bot session (Initial Greeting, welcome). If it is not, find out why and report.
3. **Every Ask for Slot / free-text question** (list them all with block ids): typed «القائمة الرئيسية», «رجوع», «القائمة السابقة», «إنهاء المحادثة», «إلغاء», «الغاء الطلب» / "main menu", "back", "end chat", "cancel" must go to Main Menu Router / the section router / Exit, before validation rejects them. Propose the mechanism (e.g. slot types that also accept these words + a Decision after each Ask), show it on one question first, then apply it to all.
4. Add a short hint to each of those questions, e.g. AR «(للعودة اكتب: القائمة الرئيسية)» / EN "(type Main Menu to go back)". Builder-mode questions → list them for me.

## Phase 3 – Smart Assistant (notes 1, 2, 9, 12, 13, 14, 16, 17, 18; also 6 and 15)

**What the tester saw:**
- The assistant mostly sends the customer to menus instead of answering (note 1). After a handoff the customer is stuck in a menu: free text there triggers NLU confirmations («تقصد قطع الغيار، صح؟», «تقصد خدمات ما بعد البيع، صح؟», «تقصد الأسعار، صح؟»), and "No" restarts the process (notes 15, 17).
- Bold broken: «*Cadillac*و*GMC*» shows raw asterisks (note 2). WhatsApp only renders `*bold*` when the `*` is at a word boundary; Arabic «و» glued to `*` breaks it.
- It doesn't know Spark EUV specs that are on the official site (note 9: https://chevrolet.ar.aljomaihauto.com/new-vehicles/spark-euv-2026/).
- Wrong roadside number: it said Cadillac = 8007525252 (note 12).
- Asked for roadside help, it sent the Customer Care menu instead of the numbers (note 13).
- It said cars can't be bought online; the site has a "Shop now" / «تسوق الآن» section: https://aljomaihauto.com/#ecommerce (note 14).
- **Yukon and Escalade were refused as "other brands"** (RULE 1 fired: «أقدر أساعدك بسيارات الجميح للسيارات فقط») (note 16). Colloquial names not understood (note 18).

**Client requirements:**
- A direct question gets a direct answer. The assistant manages the conversation; it hands off to a menu **only** for actions that need a menu or an API (booking, reschedule, cancel, test drive, price lookup, delivery status, parts request, chat with agent).
- Knows the model names and the colloquial names: اينيوس/انيوس = INEOS, يوكن/يوكون = Yukon, جمس = GMC, شفر/شفرولية = Chevrolet, كدلك = Cadillac, سكلد/اسكاليد = Escalade.
- Roadside numbers: **GMC, Chevrolet, GAC → 8007525252**; **Cadillac, INEOS → 8002442000**.

**Do (prompt v14, built on the live v13):**
1. **Model catalogue:** build the list of models per make from the existing sources (Oracle `Sales_Get_Veh_Brands` through data-action tests, `AAC_Make`, `AAC_New_Models`), add the colloquial names above, and put it in the instructions. RULE 1 must never fire for any model or nickname in that list. Show me the list.
2. **Answer vs handoff:** rewrite the routing rules: informational questions (specs, features, company info, branches, roadside numbers, online shopping) are answered directly; handoff tags only for the actions listed above. The price rule stays a handoff (no prices quoted).
3. **Roadside:** answer with the right number per make (above) directly. Also check the *Roadside Assistance 🚗* task/data uses the same numbers and fix it if not.
4. **E-commerce:** add https://aljomaihauto.com/#ecommerce to the official links list, with when to send it.
5. **Knowledge from the official site (note 9) — upload approved, public site content only:**
   - **Approved:** take the **public** model pages from the official Aljomaih sites (the five official brand domains + aljomaihauto.com): model name, trims, specs, features, and the page URL. Convert them to clean text files (one file per model, AR and EN where available) and add them to the vector store the assistant already uses (or create one and attach it to the action, if it has none).
   - **Before uploading:** send me the list of pages (URLs) and the files you will upload (name, model, language, size), plus a sample file. **Upload only after my OK.**
   - **Never upload** anything else: no project files, flow configs, exports, data tables, customer data, Oracle data or credentials.
   - Use the OpenAI key only from the existing integration/credential source; never print it. If you can't reach it without exposing it, stop and tell me.
   - Add to the instructions: answer specs from these files, and include the model-page link on the official site. If the info isn't in the files, say so and send the model-page link instead of "I can't find it".
   - Save the uploaded text files under `02 - Flow Exports/ai_knowledge_<date>/` and record the vector store id and file ids in the report.
6. **Bold:** in the instructions, require a space before an opening `*` and after a closing `*`, and no bold right after «و»; in the flow, after the action returns, make sure every `*` used for bold sits at a word boundary (e.g. «و*» → «و *»), guarded so it can't fail. Also confirm the 4th-batch `**` → `*` safety net is live.
7. **After a handoff, don't trap the customer:** when the customer types free text in the menu the assistant handed them to (instead of tapping), send it back to the assistant with the context rather than to an NLU confirmation. Propose how (e.g. `Flow.fromAI` flag + the menu's no-match/intent path → OpenAI follow-up). Same for "No" on a confirmation that came from the assistant (Phase 1.6).
8. Save as `03 - Deliverables/ai_prompt_v14.txt` and show me the diff from v13 before putting it in the flow.

## Phase 4 – Services

### Delivery Status: "another car" (note 6)
After the status («شفروليه بليزر – تم تسليم السيارة») the customer typed «لا عندي امباو» and «سيارة اخرى؟» and got «عذراً، لم أتعرف على اختيارك» twice. The client wants the AI to handle this, not the menu.
1. Check what `Sales_Get_Delivery_Status` returns for a mobile with several cars, and whether the bot shows all of them.
2. In **After Service Menu** (and Fallback Router), unrecognised free text goes to the assistant with the context (`Flow.svcSection` + the last result) instead of the "not recognised" message. Plan it with Phase 3.7; show me the plan first.

### Customer Care: transfer when the queue is off (note 8) — **no build in this batch**
The queue was off and the chat was still transferred; the customer typed «شكرا», «انهاء المحادثه», «السلام عليكم» and nobody answered. This is expected in the **test period**: every chat transferred to the agent queue is disconnected manually by our team, so the customer's next message starts a new bot session. Until that happens, the chat waits in the queue and the bot no longer answers.
1. **Don't change the transfer** and don't add schedules or working hours now.
2. Just confirm and report: what the customer sees while waiting in the queue, and that after the conversation is disconnected the next message starts fresh (Initial Greeting + welcome).
3. Add to the open items for go-live: working hours (schedule group) + agents-available check before Transfer to ACD, with a "not available" message and Contact Us. Hours to come from the client.

### Parts / Contact Us: email is NOT mandatory (note 10)
This reverses the 4th-batch rule. The customer typed «لا يوجد» and «ليس لدي بريد الكتروني» and was stuck on «يرجى إدخال بريد إلكتروني صحيح», then «الغاء الطلب» → fallback.
1. Email stays asked, but «لا يوجد», «ليس لدي», «ما عندي», «لا», «تخطي» / "none", "no", "skip", "don't have" → continue with email = «غير متوفر» / "Not provided".
2. Question text: AR «البريد الإلكتروني؟ (أو اكتب: لا يوجد)» / EN "Your email? (or type: none)".
3. A real address is still validated. Show the email body with «غير متوفر».

### Test Drive: ask for the name (note 11)
The applicant's name was not asked (today it is asked only for new customers, block 301).
1. Ask the name for **every** test drive (known customers too), AR «الاسم؟» / EN "Your name?".
2. Check `Sales_Create_Test_Drive` inputs: where does the name go for a known customer? If the API ignores it for known customers, tell me and propose where to keep it (e.g. the confirmation or a note field).
3. Show the name in the confirmation (331 / 990, builder mode → list for me).

---

## Tests after each publish (Textbots; no bookings, test drives, emails or transfers)
1. Openers «مرحبا», «هلا», «السلام عليكم», «اهلا», «hi», «hello», «-», «.» in fresh sessions: right language, welcome + privacy, no confirmation.
2. A confirmation in an Arabic session answered with «لا», «نعم», «إنهاء المحادثة».
3. At the mobile question (Delivery Status) type «القائمة الرئيسية», «رجوع», «إنهاء المحادثة».
4. Assistant: «كم الرقم المجاني؟», «ابغى رقم خدمة عملاء كاديلاك؟» (→ 8002442000), «سيارتي متعطلة بالطريق» (numbers directly), «أقدر اشتري السيارة من الموقع؟» (e-commerce link), «اسكاليد و يوكن», «ابغى مقارنة بين يوكن و اسكاليد», «ابغى مواصفات سبارك الكهربائية» (specs from the files + the model-page link), «جمس», «شفر», «كدلك», «سكلد», «انيوس», bold with brand lists (no raw `*`).
5. Assistant hands off to Sales, then type «لا ارغب بخيار المبيعات، افيدني بمعلومات عن سيارة التاهو» → back to the assistant, no confirmation.
6. Parts: email «لا يوجد» → request continues.
7. Timeout: show me the new settings and timeline (Textbots can't wait).
8. Run `checks/audit_full.py` (expect `no issues`) and `checks/long_questions.py`.

## Report
- Step 0 findings;
- the new version number(s) per phase;
- per note 1–18: what changed (block ids) or why not;
- the diff summary per publish;
- root causes for notes 3/4 («مرحبا» → English), 7 (session continues), 15 (confirmation "No");
- the model catalogue and the v13 → v14 diff;
- the test results;
- the **builder-mode blocks I must edit by hand**, with exact AR and EN text;
- what is waiting for the client, and the go-live open items (working hours + agent-availability check for Customer Care).

Save the backups, `ai_prompt_v14.txt` and `03 - Deliverables/Change Batch <date> - v<NNN> Report.md`, update `Client Feedback Tracker.xlsx` with the 5th-test rows, regenerate the docs (`docs/build_tech_reference.py`, `docs/build_full_doc.py`), and check that nothing contains a secret.

**Need my OK before:** building anything (after the plan), the upload to OpenAI (page + file list first; public site content only), any NLU change, and changing any data table.
