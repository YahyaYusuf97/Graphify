Follow-up to the 5th-test batch. Same flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). The client replied to the questions in our 5th-test email. Apply their answers below.

## Method (unchanged, mandatory)
Everything in `CLAUDE.md` and the 5th-batch prompt still applies:
- in-place SDK edit only (`checkoutAndLoadFlowByFlowNameAsync(..., forceUnlock=false)`; never `deploy_flow` / `createFlow*Async`);
- stop if the flow is locked;
- back up the published config, the ar-ae NLU and any table you touch to `02 - Flow Exports/` first;
- builder-mode blocks → list them for me with exact AR/EN text;
- new texts in expression mode on `Session.language == "ar-ae"`;
- WhatsApp limits (buttons 20, rows 24, list title 20, 10 rows) and byte-identical navigation labels;
- validate, publish, confirm `publishedVersion`, diff before/after, `audit_full.py` + `long_questions.py`;
- no secrets printed; nothing sent to third parties except as approved;
- never create test drives, bookings, emails or transfers from automated tests.

Start by telling me the current published version and what the last 5th-batch publish contained. Then give me a short plan for A–D. **Build A and B without waiting; for C and D wait for my OK on the plan.**

---

## A. Test Drive – confirm the existing customer's name (client answer to note 11)
**Client:** "Please review the flow and don't change any API structure."

**Required flow:**
1. `Sales_Get_Customer` with the mobile (unchanged).
2. **Customer exists** (`X_STATUS = "S"` with a customer ID) **and the API returned a name** → ask the customer to confirm it (new step, this was missing):
   - Question (expression, quick-reply buttons):
     - AR: «هل أنت {name}؟»
     - EN: "Are you {name}?"
   - Buttons: AR «نعم ✅» / «لا ❌», EN "Yes ✅" / "No ❌".
   - `{name}` = the name fields `Sales_Get_Customer` returns (tell me which output fields you used). Trim it; if the whole question would break a WhatsApp limit, send the name in a Communicate before a short question.
3. **Yes** → call `Sales_Create_Test_Drive` with **only the customer ID**, first and last name **empty**, exactly as before the 5th batch.
4. **No**, **or the customer does not exist**, **or the existing customer has no name** → ask the **first name and last name** (reuse the existing new-customer questions, block 301 path), then call `Sales_Create_Test_Drive` with **customer ID = -1** and the names as entered.
5. **Revert the 5th-batch change** that sends `P_FIRST_NAME` together with `P_CUSTOMER_ID`. Don't change any data action contract, input names or request templates. Check what the new-customer path sends today for the ID, and confirm it is `-1`; if it isn't, tell me before changing it.
6. Max No Matches on the confirmation → treat as **No** (ask for the names). Max No Inputs → Timeout Exit, like the other questions. Typed «القائمة الرئيسية» / «إنهاء المحادثة» etc. must work there too (5th-batch Phase 2 rule).
7. Keep the car-known skip (`Flow.carKnown`, promo path) working: the name step comes after the mobile, wherever the test drive starts from.
8. Confirmation messages (331 known customer / 990 new customer): known customer who confirmed → their API name; otherwise → the entered name. If they are builder mode, list them for me.

**Test (Textbots, stop before `Sales_Create_Test_Drive`):** known mobile → name question → Yes; known mobile → No → first/last name; unknown mobile → first/last name. Show me the inputs that **would** be sent in each case (ID and names).

## B. Delivery Status – one vehicle is correct (client answer to note 6)
**Client:** the API returns the **last vehicle the customer bought from AAC**. Nothing to change in the API.
1. Don't change the Delivery Status call or its result logic.
2. Update the assistant instructions (prompt v14 → v14.1) and, if it's in place, the 5th-batch "free text after a service → assistant" path, so that when the customer asks about another car the answer is:
   - AR: «خدمة حالة التسليم تعرض آخر سيارة تم شراؤها من الجميح للسيارات برقم جوالك. للاستفسار عن سيارة أخرى يمكنك التحدث مع أحد موظفينا أو استخدام "تواصل معنا".»
   - EN: "Delivery Status shows the latest vehicle you bought from Aljomaih Automotive with your mobile number. For another vehicle, you can chat with one of our team or use \"Contact Us\"."
   - then offer Customer Care (chat with agent / Contact Us) through the normal handoff.
3. Show me the v14 → v14.1 diff before putting it in the flow.

## C. Website content conflict (client answer about the Spark EUV pages)
**Client:** "Will be checked with team." The English Spark EUV page says 10 airbags and a 7-inch screen; the Arabic page says 4 airbags and a 10.1-inch screen.
1. Compare the AR and EN knowledge files you uploaded, model by model, and list **every** spec that differs between the two languages (model, spec, AR value, EN value, both URLs). Save it as `03 - Deliverables/Website AR-EN spec differences <date>.xlsx` so I can send it to the client.
2. Until the client confirms: for a spec that differs between AR and EN, the assistant must **not** quote a number. It says the details are on the official page and sends the model-page link. Propose how (remove those lines from the files and re-upload, or an instruction rule) and wait for my OK. Re-uploading follows the same rule as before: public site content only, show me the file list first.

## D. Customer Care working hours + holidays (client answer about working hours)
**Client:** **Sunday to Thursday, 9:00 AM to 5:00 PM** (Saudi time, Asia/Riyadh). "We need to see how to update this and how to add holidays."

**Design to propose (don't build before my OK):**
1. **Where the hours and holidays live.** Compare and recommend:
   - **Genesys schedules:** a schedule group (open Sun–Thu 09:00–17:00 + holiday closed schedules) and **Evaluate Schedule Group** before the transfer, if that action is available in a Digital Bot Flow (check; if not, say how else). Updating it needs Genesys admin access.
   - **Data tables:** `AAC_CC_Hours` (days, open time, close time) and `AAC_Holidays` (date or date range, name AR/EN, Active), read by the bot in Saudi time. The client can update these themselves with the API access they already have (`Aljomaih Tables API`, division Aljomaih).
   I expect the data-table option to suit the client better, because they already maintain the `AAC_*` tables. Tell me if you disagree and why.
2. **Before Transfer to ACD (1743 EN / 1748 AR):** open (inside hours and not a holiday) → transfer as today. Closed →
   - AR: «عذرًا، فريق خدمة العملاء غير متاح حاليًا. أوقات العمل من الأحد إلى الخميس، من 9:00 صباحًا إلى 5:00 مساءً. يمكنك ترك رسالة عبر "تواصل معنا" وسنعود إليك.»
   - EN: "Sorry, our customer care team is not available right now. Working hours are Sunday to Thursday, 9:00 AM to 5:00 PM. You can leave a message through \"Contact Us\" and we will get back to you."
   - On a holiday, use the holiday name if there is one (e.g. «… بمناسبة {holiday}»).
   - Then a menu: «تواصل معنا 💬» / "Contact Us 💬", Main Menu, End Chat (byte-identical labels).
   - The hours in the text must come from the same source as the check, so changing the hours never leaves a wrong message.
3. **Agents available:** also propose a check that at least one agent is on queue in *Aljomaih Test* (e.g. a Genesys data action on the queue observation query). If nobody is on queue inside working hours, show the same message without the hours sentence. Say what it needs (new data action, permissions).
4. **Test period:** our team still disconnects transferred chats manually; nothing here changes that.
5. **Client guide:** once built, add a section to `05 - Documentation/Aljomaih WhatsApp Bot - Data Tables Guide.md` (or a short guide for the Genesys option) that explains, with examples, how to change the hours and add/remove a holiday. Regenerate its PDF.

---

## Report
- version number(s);
- A: the blocks changed/added, which name fields you used, the would-be inputs for the three test cases, and confirmation that no data action changed;
- B: the v14.1 diff;
- C: the differences sheet + your proposal;
- D: the design comparison and recommendation (then the build report after my OK);
- the builder-mode blocks I must edit by hand with exact AR/EN text;
- `audit_full.py` / `long_questions.py` results.

Save the backups and `03 - Deliverables/Change Batch <date> - v<NNN> Report.md`, update `Client Feedback Tracker.xlsx` with the client's answers, regenerate the docs, and check that nothing contains a secret.
