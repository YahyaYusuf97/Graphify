Small fix in one task. Flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). Only the task **Brand Picker** (model-line list, «اختر الطراز» / "Select the model") may change.

## What happened on WhatsApp (Arabic, Chevrolet, from Current Promotions)
1. «اختر الطراز» list → tapped «المزيد» → page 2 list.
2. Tapped **«سوبربان»** → «من فضلك اختر الطراز من القائمة» (not recognized).
3. Tapped «سوبربان» again → same message.
4. Tapped «سبارك» from the re-sent list → (check what happened; it should have worked).

## Likely cause (check it, don't assume)
Oracle `Sales_Get_Veh_Brands` returns the Arabic name **«سوبربان »** with a **trailing space** (known data issue O4 in the handover). WhatsApp trims the row title, so the tapped reply «سوبربان» doesn't equal the option «سوبربان », and the menu treats it as no-match. Any other `BRAND_DESC` with leading/trailing/double spaces fails the same way.

## Method (mandatory, as always)
- Read `CLAUDE.md`. `check_env.py` + `checks/audit_full.py` first.
- In-place SDK edit only (`checkoutAndLoadFlowByFlowNameAsync(..., forceUnlock=false)`; **never** `deploy_flow` / `createFlow*Async`). Locked → stop and tell me. Check the flow id after checkout and before publish; validate; unlock without saving on error.
- Back up the published config + ar-ae NLU to `02 - Flow Exports/` first.
- **Don't change any data action.** Don't touch `Hadef_BusinessWhatsApp`.
- Keep navigation labels byte-identical («المزيد», «القائمة السابقة ↩️», «القائمة الرئيسية 🏠»), rows ≤ 24, title ≤ 20, max 10 rows.

## Step 0 – confirm (report before changing)
1. Run a data-action test of `Sales_Get_Veh_Brands` for `P_MAKE=1`, `P_LANGUAGE=AR` and `US`, and for `T`, `6`, `7`, `8`. List every `BRAND_DESC` / `BRAND_CODE` that has a leading, trailing or double space (show them with quotes).
2. Show me how Brand Picker builds the list rows and how it maps the tapped label back to `BRAND_CODE` (block ids, expressions), including the page-2 path after «المزيد».
3. If you can, read this conversation's transcript in Genesys (Arabic session, today, «سوبربان» then «سبارك») and tell me exactly what the bot received and why each tap failed.

## Change
1. Build every row label with **`Trim()`** (and collapse double spaces with `Replace(x, "  ", " ")`), on every page.
2. Make the label → code mapping compare trimmed values on both sides, so a reply always finds its `BRAND_CODE`, also on page 2 and on the re-sent list after a no-match.
3. The promo key and everything after the pick must still use the **original `BRAND_CODE`** (e.g. `1|TAHOE`); don't change the key.
4. Nothing else changes.

## Tests (Textbots where possible; otherwise tell me what to tap on WhatsApp)
- Chevrolet AR and EN: page 1 item, «المزيد» → page 2 item (**سوبربان / Suburban**), back to page 1 → «سبارك».
- GMC → Yukon; one model with a space problem from Step 0.
- From Current Promotions, the pick must reach the promotion image (all 10 promotions are Active in the portal).
- `audit_full.py` (expect `no issues`) and `long_questions.py`.

## Report
New version, Step 0 findings (the spaced names list + the transcript), blocks changed with before/after expressions, diff summary, test results. Also list the spaced names for the client to fix in Oracle (O4).
