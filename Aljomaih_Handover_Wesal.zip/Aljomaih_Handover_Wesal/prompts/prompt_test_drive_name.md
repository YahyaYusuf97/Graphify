This batch changes **only the Test Drive name step**. Same flow: "Aljomaih Automotive WhatsApp " (trailing space), id b8f8eb7e-6b92-43cc-b516-82a40a49dcdc, digitalBot, Hadef org (mypurecloud.de / prod_eu_central_1). It comes from the client's answer to 5th-test note 11. Nothing else in the flow may change.

## Client's answer (exact requirement)
> Please review the flow and don't change any API structure.
> Get_Customer API called first to validate customer exists or not (Mobile no as input).
> Depend on the result from the API BOT should confirm customer name if customer already exists >>>> This step missing.
> If customer confirm his name flow continue to call Create_Test_Drive API without first and last name, Only with ID.
> If customer not exists or he didn't confirm his name, flow should ask for his first and last name.
> Then call the Create_Test_Drive API with ID=-1 and first name and last name as entered.

## Method (mandatory)
- Read `CLAUDE.md` first. Run `python "04 - Scripts/check_env.py"` and `python "04 - Scripts/checks/audit_full.py"` (expect `no issues`).
- Credentials only from `creds/` or environment variables. **Never print, paste or ask for a secret in chat.** Nothing goes to any third-party service.
- **Do not modify `Hadef_BusinessWhatsApp`.**
- In-place SDK edit only (`04 - Scripts/sdk/run.sh`): `checkoutAndLoadFlowByFlowNameAsync("Aljomaih Automotive WhatsApp ", digitalBot, forceUnlock=false)`. **NEVER** `deploy_flow` / `createFlow*Async`. If the flow is locked, stop and tell me. Check the flow id after checkout and before publish. Validate; on any error unlock without saving.
- Back up the published config and the ar-ae NLU version to `02 - Flow Exports/` first.
- **Don't change any data action** (contract, input names, request/response templates) — not `Sales_Get_Customer`, not `Sales_Create_Test_Drive`.
- Builder-mode blocks → don't touch; list them for me with exact AR/EN text. New texts in **expression mode** on `Session.language == "ar-ae"`.
- WhatsApp limits: buttons ≤ 20, list rows ≤ 24, list title ≤ 20, max 10 rows. Navigation labels byte-identical: «القائمة السابقة ↩️», «القائمة الرئيسية 🏠», «إنهاء المحادثة 👋» / "Previous Menu ↩️", "Main Menu 🏠", "End Chat 👋".
- Expressions: no `not` (use `IsNotSetOrEmpty(x) == false`), no `Random`, no `Min`.
- **Never create a test drive from an automated test.**

## Step 0 – read before changing (report it)
1. Current published version.
2. Task **Sales Test Drive** today, block by block from the mobile question to `Sales_Create_Test_Drive`: the `Sales_Get_Customer` call and its outputs (which fields hold the customer ID and the name), the known/new decision, block 301 (name question for new customers), and **exactly what is sent** to `Sales_Create_Test_Drive` in each path today (`P_CUSTOMER_ID`, `P_FIRST_NAME`, `P_LAST_NAME`, …).
3. The 5th-batch change that asks existing customers for the name and sends `P_FIRST_NAME` together with `P_CUSTOMER_ID`: which blocks it added or changed.

Then give me a short plan and build it without waiting, unless something is ambiguous.

## Change
1. **Revert the 5th-batch name change** for existing customers (the name question and sending `P_FIRST_NAME` with `P_CUSTOMER_ID`).
2. After `Sales_Get_Customer`:
   - **Customer exists** (`X_STATUS = "S"` with a customer ID) **and the API returned a name** → new confirmation question (expression mode, quick-reply buttons):
     - AR: «هل أنت {name}؟»
     - EN: "Are you {name}?"
     - Buttons: AR «نعم ✅» / «لا ❌», EN "Yes ✅" / "No ❌".
     - `{name}` = the name from `Sales_Get_Customer` (first + last, trimmed). If a long name could break a WhatsApp limit, send the name in a Communicate first and keep the question short.
   - **Yes** → call `Sales_Create_Test_Drive` with **the customer ID only**; first and last name **empty** (the same values the known-customer path sent before the 5th batch).
   - **No**, **or the customer does not exist**, **or the API returned no name** → ask the **first name and last name** (reuse the existing new-customer questions, block 301 path) → call `Sales_Create_Test_Drive` with **customer ID = -1** and the first and last name as entered.
3. Confirm that the new-customer path sends `-1` as the ID today. If it sends something else, tell me before changing it.
4. On the confirmation question:
   - Max No Matches → treat as **No** (ask for the names).
   - Max No Inputs → Timeout Exit, like the other questions.
   - Typed «القائمة الرئيسية» / «إنهاء المحادثة» / "main menu" / "end chat" must work, the same way as the other questions after the 5th batch.
5. Keep everything else in the test drive as it is: the car-known skip (`Flow.carKnown`, Price Range → Test Drive), the promo path, showroom, day and time steps.
6. Confirmation message after booking (331 known customer / 990 new customer): confirmed customer → the API name; otherwise → the entered name. If they are builder mode, list them for me with the text.

## Tests after publish (Textbots — stop **before** `Sales_Create_Test_Drive`)
1. Known mobile with a name → «هل أنت …؟» → **Yes** → continues without asking the name.
2. Known mobile → **No** → asks first and last name.
3. Unknown mobile → asks first and last name.
4. Known mobile but no name returned (if you can find one) → asks first and last name.
5. Arabic and English sessions.
6. For each case, show me the inputs that **would** be sent to `Sales_Create_Test_Drive` (customer ID, first name, last name).
7. Run `checks/audit_full.py` (expect `no issues`) and `checks/long_questions.py`.

## Report
- the new version number;
- Step 0 findings (the old paths and what each sent);
- blocks changed / added / removed (tracking ids) and the diff summary — only Sales Test Drive may change;
- the name fields you used from `Sales_Get_Customer`;
- confirmation that no data action changed;
- the test results with the would-be inputs per case;
- builder-mode blocks I must edit by hand, with exact AR/EN text.

Save the backups and `03 - Deliverables/Change <date> - v<NNN> Test Drive name confirmation.md`, update `Client Feedback Tracker.xlsx` (note 11), regenerate the docs, and check that nothing contains a secret.
