# CLAUDE.md – Aljomaih WhatsApp Bot (Wesal team handover, 8 Nov 2026)

You are helping a Wesal CX engineer who is taking over the **Aljomaih Automotive WhatsApp bot** on Genesys Cloud. Read this whole file before doing anything. It is the single source of truth for the project's state on **8 November 2026**. It contains **no secrets**; never add any.

If the engineer gives you the original handover folder (`AAC Bot - Handover`, from Ahmed Ashraf, 1 Oct 2026), its `CLAUDE.md` and `05 - Documentation/` are still valid for *how the bot is built*. This file adds everything that happened **after 1 Oct** and overrides the old files where they differ.

---

## 1. The project in one paragraph

Aljomaih Automotive Company (الجميح للسيارات, Saudi Arabia; Chevrolet, GMC, Cadillac, GAC, INEOS) gets a bilingual (Arabic/English) WhatsApp self-service bot built by **Hadef Information Technology / Wesal CX** on **Genesys Cloud**. The bot is one **Architect Digital Bot Flow**. It talks to the client's **Oracle EBS** (sales and aftersales web services), reads its content from **Genesys data tables** (`AAC_*`), answers free text with **OpenAI** (smart assistant), sends **emails through Microsoft Graph**, shows **promotions from the Wesal promotions portal**, and can **transfer to a live agent**. It runs today in the **Hadef org** on the **Wesal test WhatsApp number** against the **Oracle TEST** server. The client is in UAT (5 test rounds done); go-live (move to Aljomaih's own Genesys org and WhatsApp number) is expected **late Nov / Dec 2026**.

---

## 2. Where things are

| Thing | Value |
|---|---|
| Genesys org (today) | **Hadef**, region `mypurecloud.de` (Frankfurt). API `https://api.mypurecloud.de/api/v2`, login `https://login.mypurecloud.de`, UI `https://apps.mypurecloud.de` |
| SDK region name | `prod_eu_central_1` |
| Bot flow | `Aljomaih Automotive WhatsApp ` (**trailing space**), id `b8f8eb7e-6b92-43cc-b516-82a40a49dcdc`, type digitalBot, division Home |
| Published version | **144.0 on 1 Oct**; several versions published since (4th/5th test rounds, test-drive change). **Always read the live `publishedVersion` first** (`GET /flows/{id}`) |
| Inbound flow | `Hadef_BusinessWhatsApp` (block 482 calls the bot). **Shared with other Hadef demos. NEVER modify it.** It sets the input `Flow.language` |
| Division `Aljomaih` | `87ce39e1-cb87-4fc7-a3a7-d6069e6411dc`: all `AAC_*` tables, queue **Aljomaih Test** (`cd6eeb0c-748a-4f33-93b3-350a075de01e`), the client's API client |
| Test copy | `Aljomaih AI TEST` – never connect it to WhatsApp. Other "Aljomaih…" bot flows are old demos |
| Oracle | TEST host `jebstest.aljomaihauto.com` (IP-restricted: test only via Genesys data-action tests). Production will be `ebsprod` |
| Promotions portal | `https://portal.wesal.cloud/en/tables/promotions` (Wesal-built; sign-in required). Bot API `GET https://portal.wesal.cloud/api/bot/promotions[/{key}]`, header `x-api-key` |
| Ticket | Zoho Desk **#11425** "Ahjomaih ChatBot Implementation" (all client email goes here) |
| Original handover | `AAC_Bot_Handover_2026_10_01_v144_PRIVATE_with_credentials.zip` in the team share (`…\Project\aljomaihauto\`). Contains docs, exports, scripts, prompts **and a `creds/` folder** |

### OAuth clients (Hadef org) – no secrets here
| Client | Purpose |
|---|---|
| `Ashraf 2` (`c9db9559-…`) | Architect SDK deploys (`sdk/run.sh`), Textbots tests. Used through the MakingChatbots "genesys-cloud-architect" Claude Code plugin |
| `Ahmed Ashraf Al jomih` (`2bacaf41-…`) | Project scripts (`gcx.py`). **Its secret in the handover zip no longer works** (`invalid_client`) – regenerate if you need it |
| `Aljomaih Tables API` (`0ef82d8b-4855-419c-81c5-8a97da588cb5`) | **The client's** access to the `AAC_*` tables (division Aljomaih only). Secret was regenerated ~27 Oct and re-sent to Ayman; works since 29 Oct |
| `GenesysCloudDataAction…` | Runtime reads of the tables by the bot |

### Credentials rules
- Credentials live only in local `creds/*.json` (from the zip, possibly outdated) or env vars (`GC_CLIENT_ID/SECRET/REGION`, `AJ_CLIENT_ID/SECRET`, `GENESYS_CLIENT_ID/SECRET`). Run `python "04 - Scripts/check_env.py"` – it reports without printing values.
- **Never print, paste, log or ask for a secret in chat.** If something is missing, ask the engineer to fill the file.
- The promotions-portal API key was **rotated on ~8 Nov** (the earlier key now returns 401). The bot's Genesys integration for the portal must hold the **current** key.
- **Never send any project file, config or export to a third-party service** (paste sites, online JSON/diff tools, httpbin…). Only Genesys Cloud, and Oracle/OpenAI/Graph/portal through the existing data actions. (One exception was approved in the 5th round: public Aljomaih website content uploaded to the assistant's OpenAI vector store.)

---

## 3. How the bot works (summary – details in the original docs §4–§8)

**Main menu (10):** Sales 🚘 · Aftersales 🔧 · Parts ⚙️ · Customer Care 🎧 · Locations & Hours 📍 · Promotions 🎁 · Notifications 📢 · Ask the smart assistant 🤖 · Change Language («تغيير اللغة / English» and "Change Language / عربي") · End Chat 👋.

| Journey | How it works |
|---|---|
| Sales → Promotions | Make (`AAC_Make`) → model line (Oracle `Sales_Get_Veh_Brands`, paged 7 + More) → promotion by key `make|BRAND_CODE` from the **portal API** (moved from `AAC_Promotions` in Nov – confirm in the live flow, §7 #3) → image → Test Drive / Price Range / Previous / Main |
| Sales → Price Range | make → line → model → trim (List Picker, tap only) → year → `Sales_Get_Veh_Price` → min/max + VAT note → "Book a test drive?" Yes keeps the car (`Flow.carKnown`) |
| Sales → Test Drive | car → mobile → `Sales_Get_Customer` → **name confirmation** (see §5) → region → showroom (`Sales_Get_Veh_Branches`) → day (next 8 days, Friday off) → time (`AAC_TestDrive_Slots`) → `Sales_Create_Test_Drive` |
| Sales → Delivery Status | mobile only (`P_CUST_ID` empty). Returns **the last vehicle bought** (client confirmed this is correct) |
| Sales → New Models | `AAC_New_Models` (not the old `AAC_NewModels`) |
| Aftersales → Book | VIN last 8 → `GET_VALIDATE_VIN` → type → city → centre (auto if one) → month → day → time (`DATE_SLOTS V2`, needs `REQ_APP_TYPE`) → `BOOK_WS_APP` → full confirmation (number, centre, city, date dd/MM, time ص/م, 15-min note) |
| Aftersales → Reschedule / Cancel | appointment no. + VIN → `VALIDATE_VIN_APP_ID V2` → straight to month/day/time → `RES_WS_APP`; cancel only if Oracle confirms |
| Aftersales → Service Updates / Repair Status | `GET_ACTIVE_RECALL`; `GET_CURRENT_REPAIR_STATUS` (full VIN) |
| Parts / Contact Us | questions incl. name, city, email (**optional**: «لا يوجد» / "none" → «غير متوفر»), details → `Graph_Send_Mail` (recipients/on-off in `AAC_Email_Settings`, live to `whatsapp@aljomaihauto.com`) |
| Customer Care → Chat with Agent | Transfer to ACD → queue **Aljomaih Test**. **No working hours yet** (24/7). In test, the team closes transferred chats manually |
| Smart assistant | OpenAI Responses API (`ChatGPT_OpenAI_2026` + `…FollowUp_2026`), instructions = the live prompt in the action input (v13/v14 after the 4th and 5th rounds; `ai_prompt_v12.txt` in the zip is outdated – read the live one). Answers directly; hands off only for actions; replies in the customer's typed language and switches the session language |
| After every service | «هل تحتاج إلى أي شيء آخر؟» → End Chat / Previous / Main / **Ask the smart assistant 🤖** |

**Rules every task follows**
- Each text is an `If(Session.language == "ar-ae", …, …)` expression or a builder-mode message (AR + EN fields).
- Routers (`Main Menu Router`, `Sales Menu Router`, `Aftersales Router`, `Parts Router`, `Customer Care Router`, `Locations Router`) re-open a section in the right language. Jump to a router, never straight to a language task.
- Max No Matches → **Fallback Router**; no input → reminder after **2.5 min**, **Timeout Exit** at 5 min (own goodbye text).
- Every free-text question accepts «القائمة الرئيسية» / «رجوع» / «القائمة السابقة» / «الغاء الطلب» / «إنهاء المحادثة» (and EN) and shows the hint «(للعودة اكتب: القائمة الرئيسية)».
- "Did you mean …?" NLU confirmations were **switched off** (5th round). Greetings go straight to the main menu.

---

## 4. Hard rules (break none of these)

1. **Never modify `Hadef_BusinessWhatsApp`.**
2. **Never use `createFlow*Async` / `deploy_flow` on the existing bot.** It deletes and re-creates the flow (new id). Edit **in place** with the Architect Scripting SDK: `checkoutAndLoadFlowByFlowNameAsync("Aljomaih Automotive WhatsApp ", digitalBot, forceUnlock=false)`; check the flow id after checkout and before publish; validate; unlock **without saving** on any error.
3. **If the flow is locked** (someone in Architect), stop and say so.
4. **Back up first**: published config (`GET /flows/{id}/versions/{v}/configuration`) + ar-ae NLU domain version → `02 - Flow Exports/`.
5. **Builder-mode texts are edited by hand** in Architect (the SDK cannot). Every new text you add must be expression mode on `Session.language == "ar-ae"`. List the builder-mode blocks for the engineer with exact AR/EN text.
6. **Verify every publish yourself**: `publishedVersion`, diff old vs new config (only intended blocks change; NLU, intent mappings and list bindings identical), `checks/audit_full.py` → `no issues`, `checks/long_questions.py`.
7. **Never create bookings, test drives, cancellations, emails or transfers from automated tests.** Textbots (`POST /textbots/botflows/sessions`, needs `channel.userAgent` + `inputData:{variables:{}}`) can drive up to any question; the engineer tests side-effects on WhatsApp.
8. **Data actions**: a published contract can't change – create a `V2`. Config changes via `/draft` → `PATCH` → `/draft/test` → `/draft/publish`. A test returns HTTP 200 even on failure – check `success`. Velocity templates can't use `#foreach`.
9. **Don't change any Oracle API structure** (client instruction, 20 Oct).
10. **The move to the Aljomaih org** happens only when the team decides (§8).
11. Reply to the engineer in their language (the team writes Egyptian Arabic); client emails and reports are in English.

### WhatsApp limits that shaped everything
- Buttons ≤ **20** chars; list rows ≤ **24**; **list title (= the question) ≤ 20**; max **10** rows. One over-long option → the whole message is silently not delivered.
- Typed replies to a list only match options **in the current message** (items on another page can't be typed).
- List Pickers accept taps only.
- Navigation labels must be **byte-identical**: «القائمة السابقة ↩️», «القائمة الرئيسية 🏠», «إنهاء المحادثة 👋», "Previous Menu ↩️", "Main Menu 🏠", "End Chat 👋".
- WhatsApp trims row titles: a value with a leading/trailing space never matches when tapped (see the Suburban bug, §7).
- Don't wrap builder-mode variables in `*` (Genesys adds spaces → raw asterisks).

### Architect expression gotchas
`not` is rejected (use `IsNotSetOrEmpty(x) == false`); `DayOfWeek()` 1 = Sunday; no `Random()`, no `Min()`; Literal `""`, Expression `""` and NOT_SET differ; the SDK runner times out at 90 s (config ≈ 3.5 MB → 408 on slow uploads; retry).

---

## 5. What changed after the 1 Oct handover (timeline)

| Date | What |
|---|---|
| 1 Oct | Ahmed Ashraf hands over (v144). Mohamed Salah (Senior Genesys Developer) takes the project |
| 6–7 Oct | **4th test** (Amal, 11 notes); changes reported done on 7 Oct (Abdullah Elsheikh's email). Requested scope (`prompt_4th_test_batch.md`): Timeout Exit task with its own message; booking confirmation in the client's format (date dd/MM, time ص/م); assistant replies in the customer's language, `**`→`*`, closing question in the reply language, session language switch; bilingual language labels; parts/contact name, city, email, details. **Exact implementation (variable names, tags) – read it from the live flow** |
| 15 Oct | **5th test** (Amal, 18 notes) |
| 19 Oct | 5th round done (email on ticket): assistant answers directly, model catalogue + nicknames (يوكن، جمس، شفر، كدلك، سكلد، انيوس), official model pages in the OpenAI vector store, roadside numbers (**Chevrolet/GMC/GAC 8007525252; Cadillac/INEOS 8002442000**), e-commerce link `https://aljomaihauto.com/#ecommerce`, bold fixed; greetings with no confirmation; confirmations off; welcome + privacy at every new chat; reminder 2.5 min / end 5 min; "Ask the smart assistant" after every service; email optional; a way back from every question |
| 20 Oct | Client answers: Delivery Status single vehicle is correct; **test drive must confirm the existing customer's name**; website AR/EN spec conflict (Spark EUV) to be checked by their web team; **working hours Sun–Thu 9:00–17:00**, holidays to be designed |
| 21 Oct | Test-drive name confirmation live (see below). Client test numbers added to the test list on request. Go-live prerequisites sent by Mahmoud Mandour (UAT confirmation, agent list, Meta account-owner meeting, promotions may follow go-live within 2 weeks) |
| 25 Oct | Ayman: testing ~80 %, promotions still to test, add **all current agents** to the WhatsApp queue, **one more month** before go-live |
| 26–29 Oct | Client's Tables API token failed → `Aljomaih Tables API` secret regenerated; "AAC_NewModels missing" → explained (`OLD_AAC_NewModels`, live table is `AAC_New_Models`); resolved in a call on 29 Oct |
| 4–8 Nov | Promotions move to the **Wesal promotions portal** API. 8 Nov: all 10 promotions set **Active**, end date 2026-12-31, images uploaded to the portal (for the client's test; Ayman had set most to Inactive on 5 Nov). Found the **Brand Picker trailing-space bug** (Suburban) |
| 9 Nov, 14:00 | **Offers portal presentation** to the client (confirmed by Ayman) |

### Test drive – the current required logic (client spec, 20 Oct; live 21 Oct)
1. `Sales_Get_Customer` with the mobile.
2. Exists **and** a name returned → «هل أنت {الاسم}؟» / "Are you {name}?" with «نعم ✅»/«لا ❌».
3. **Yes** → `Sales_Create_Test_Drive` with the **customer ID only**, first/last name empty.
4. **No**, not found, or no name → ask first + last name → `Sales_Create_Test_Drive` with **ID = -1** and the names.
5. Unrecognised ×3 → ask the names. Don't change any API structure.

---

## 6. Promotions (portal)

- The client edits promotions in the portal (`portal.wesal.cloud`, menu Promotions). Fields: row key (locked), EN/AR name, model year, **image for English chats / Arabic chats** (upload JPEG/PNG ≤ 5 MB; stored at `https://portal.wesal.cloud/uploads/<uuid>.jpg`, public), start/end date, make, brand, status.
- The portal says **start/end dates are "NOT READ BY THE BOT"**; **Status (Active/Inactive)** controls visibility.
- Keys: `make|BRAND_CODE` exactly as Oracle `Sales_Get_Veh_Brands` returns `BRAND_CODE` (make codes: Chevrolet `1`, GMC `T`, Cadillac `6`, GAC `7`, INEOS `8`), plus `SERVICE|ALL` and `PARTS|ALL`.
- Rows on 8 Nov: `1|CAPTIVA`, `1|CAPTIVA PHEV`, `1|GROOVE`, `1|SPARK`, `1|TAHOE`, `1|TRAVERSE`, `T|ACADIA`, `T|YUKON`, `PARTS|ALL`, `SERVICE|ALL` – all Active with images.
- API: `GET /api/bot/promotions` → `{entities:[…], total}`; `GET /api/bot/promotions/{url-encoded key}` → object, or **404** `{"found":false}`; no key → 401. Fields mirror the old `AAC_Promotions` columns.
- The old images on `aljomaihauto.sa/whatsapp/...` return **HTTP 500** – don't use them.
- `AAC_Promotions` table stays as a backup; don't delete it.
- To get Oracle model codes: test the data action `Sales_Get_Veh_Brands` (`custom_-_9c981039-b27e-4db7-b1c9-5adbbb76e4c1`) via `POST /api/v2/integrations/actions/{id}/test` with `{"P_MAKE":"1","P_LANGUAGE":"US"}` → `finalResult.BRAND_CODE[]`.

---

## 7. Open items (8 Nov 2026)

| # | Item | Owner | State / next step |
|---|---|---|---|
| 1 | **Brand Picker trailing-space bug**: Oracle returns «سوبربان » (trailing space); WhatsApp trims the tapped title → "please choose from the list". Fix: `Trim()` + collapse double spaces on row labels and on the label→code match, every page; keep `BRAND_CODE` for the promo key. Prompt ready: `prompt_brand_picker_trim.md` | Wesal | Not yet applied |
| 2 | Offers/promotions portal demo and client acceptance; agree which promotions stay Active | Wesal + client | Meeting 9 Nov 14:00 |
| 3 | Confirm the bot's portal integration has the **rotated API key** and reads the portal (not the table) | Wesal | Check |
| 4 | **Working hours + holidays + agents-available check** before Transfer to ACD (Sun–Thu 9:00–17:00 Riyadh). Proposed: data tables `AAC_CC_Hours` / `AAC_Holidays` (client-editable) or a Genesys schedule group; closed → message + Contact Us | Wesal | At go-live |
| 5 | Website AR/EN spec conflicts (Spark EUV: EN 10 airbags/7", AR 4 airbags/10.1") | Client web team | Waiting |
| 6 | Oracle TEST data fixes (O4): missing Arabic names (Captiva PHEV, CANYON, HUMMER), «سوبربان » space, long showroom names, Jeddah hours "8pm", Captiva PHEV trim "---" with no years, price max (API vs old bot) | Client | Waiting |
| 7 | **UAT sign-off** by the client (they asked ~1 month from 25 Oct) | Client | Pending |
| 8 | **Go-live** (§8): Meta account-owner meeting, agent list (all current agents), move to the Aljomaih org, `ebsprod`, production credentials | Both | After UAT |
| 9 | Security hygiene: handover zip has a `creds/` folder → keep it private, rotate what's still valid; never re-share the portal API key in chat | Wesal | Ongoing |

Known limitations to explain, not "fix": typed items from another page of a list; trim list tap-only; free text typed while a button menu is open can't reach the assistant (hence "Ask the smart assistant" after every service); the platform has one fixed no-input timeout (2.5 min ×2).

---

## 8. Go-live checklist (from the original §13, still valid)

1. Export the flow (`.i3DigitalBotFlow`), import into the Aljomaih org (replace their old `Aljomaih WhatsApp` or import beside it).
2. Re-point every table id to that org's tables (`AAC_Make`, `AAC_Regions`, `AAC_Notifications`, `AAC_New_Models`, `AAC_TestDrive_Slots`, `AAC_Email_Settings`, `AAC_Loc_Content`, …). Recreate anything added after 24 Sep (test-drive slots, email settings, `VALIDATE_VIN_APP_ID V2`, Graph integration, queue, **portal promotions integration**, working-hours tables).
3. Oracle `jebstest` → `ebsprod`, production credentials in the integration.
4. WhatsApp: their number → their inbound message flow → Call Digital Bot Flow → this bot.
5. Agents: real queue(s), all current agents, working hours + holidays.
6. Emails: recipients in `AAC_Email_Settings`; Graph app permission for the production sender.
7. Full regression; on WhatsApp: booking, reschedule, cancel, test drive (Yes / No / new customer), email, transfer, promotions.

---

## 9. People

| Name | Side | Role in the project |
|---|---|---|
| Mohamed Salah | Wesal | Senior Genesys Developer – current owner (since 1 Oct) |
| Mohamed Shaaban | Wesal | CX Engineer – helped on 21 Oct changes |
| Ahmed Ashraf | Wesal | Built the bot until 1 Oct (original handover) |
| Mahmoud Mandour, Bassam Nassef | Wesal | IT Project Managers (go-live planning, status) |
| Abdullah Elsheikh, Mahmoud Nada | Wesal | In copy on the ticket |
| Ayman Abdulrazek | Aljomaih | Senior Oracle Consultant – technical lead, Oracle APIs, Tables API, approvals |
| Amal Al Amoudi | Aljomaih | Call Center Manager – runs the test rounds (Excel "Nth TEST -WhatsApp - Aljomaih - Alwesal.xlsx") |
| Omer Konna | Aljomaih | In copy |
| Hussain | Aljomaih IT | Provided the Microsoft Graph app |

---

## 10. How to work with the engineer

- **Session start:** `pip install -r requirements.txt`; `python "04 - Scripts/check_env.py"`; check `publishedVersion` and the lock; `python "04 - Scripts/checks/audit_full.py"` (expect `no issues`).
- **A new client test round** (Excel with notes + screenshots): extract every note and image, map each to blocks/tasks, then write a **change prompt** in the style of `04 - Scripts/sdk/prompt_3rd_test_batch.md`: method rules → Step 0 (read and report) → one section per note with block ids and exact AR/EN texts → tests → report → builder-mode blocks for hand edits. Ask the engineer before building anything ambiguous.
- **Client email**: English, short, bullet points, explain WhatsApp/platform limits plainly; draft it, don't send it.
- **Tracker and records:** `03 - Deliverables/Client Feedback Tracker.xlsx`; client replies → `CST Responses/`; sent emails → `03 - Deliverables/Email <date> - <topic>.md`; change reports → `03 - Deliverables/Change Batch <date> - v<NNN> Report.md`; regenerate docs after each publish (`docs/build_tech_reference.py`, `docs/build_full_doc.py`).
- **Browsing:** use the engineer's Chrome (Claude in Chrome); the portal needs the engineer to sign in.
- **Test data (Oracle TEST):** known customer mobile `0561059555`; unknown `0511111111`; VIN that books `9J110129` (Suburban); VIN with a repair visit `NR148267`; delivery data `0561059555`; no delivery data `0599999999`.
